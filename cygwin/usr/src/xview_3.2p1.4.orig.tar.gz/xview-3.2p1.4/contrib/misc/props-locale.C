#
# @(#)C 1.3 91/09/14;SMI
#
# Workspace Properties localization panel configuration file - Specific Setting
# Specific Settings for the C locale
#
#	LC_MESSAGES="C"		-> display language is English
#	Basic_Locale="C"	-> basic locale setting is English
#
# Category_name=default_value,value:label[[,value:label]...]
#
input_language=C;C|English
display_language=C;C|English
time_format=C;C|12/31/89 21:30:30
numeric_format=C;C|10,000.0
